<!-- CSS -->


<!-- favicon -->
<link rel="shortcut icon" type="image/png" href="public/media/favicon/shopping-cart.png"/>
<!-- ./favicon -->

<!-- FontAwesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css" />
<!-- ./FontAwesome -->

<!-- GoogleFont -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
<!-- ./GoogleFont -->

<!-- CustomCSS -->
<link rel="stylesheet" type="text/css" href="public/css/style.css">
<!-- ./CustomCSS -->