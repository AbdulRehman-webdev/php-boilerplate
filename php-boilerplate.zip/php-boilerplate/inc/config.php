<?php 
$Server = "localhost";
$Username = "root";
$Password = "";
$DbName = "shoppingwhoppingpk";
$conn = mysqli_connect($Server, $Username, $Password, $DbName);
// check
if(!$conn){
	echo "Error! Something Went Wrong.<br>
	<p>Database connection is lost. contact to the administrator of the website</p>";
}
?>